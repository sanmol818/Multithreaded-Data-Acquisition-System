from PyQt5.QtWidgets import *
import sys
from events import *
if __name__ == '__main__':          #for starting the main function
    
    app = QApplication(sys.argv)    #For initialising the GUI 
    ex = Events()                  #For threading and events
    sys.exit(app.exec_())           # runs main loop, and returns a status code when it exits

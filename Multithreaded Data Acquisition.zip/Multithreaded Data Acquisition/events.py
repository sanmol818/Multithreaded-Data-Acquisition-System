from PyQt5.QtWidgets import *
import subprocess
import threading,csv

from PyQt5 import QtGui, QtCore 
from PyQt5.QtCore import (QCoreApplication, QObject, QRunnable, QThread,
                          QThreadPool, pyqtSignal,QDate,QRect,QTimer)
from workerobject import *
from guilayout import *

class Events(QtCore.QObject):

    signalStatus = QtCore.pyqtSignal(str)

    def __init__(self, parent=None):
        super(self.__class__, self).__init__(parent)

        # Create a gui object.
        self.gui = Window()        
        self.gui.showFullScreen() #creates a full screen window
        self.TimerT = 10      
        self.timeEd=30
        
        # Setup the worker object and the worker_thread.
        self.worker = WorkerObject(self.TimerT)
        self.worker_thread = QtCore.QThread()
        self.worker.moveToThread(self.worker_thread)
        self.worker_thread.setTerminationEnabled(True)
        self.worker_thread.start()
        self.gui.start.setEnabled(False)
        # Make any cross object connections.
        self.temp = 0
        self.header =[]
        self.header.append("Time"  )                   
        for i in range(4): #defining temperature sensor headers
                    self.header.append("T" + str(i))
                    
        self.header.append("P1"  ) #defining pressure sensor headers
        self.header.append("P2"  )
        self._connectSignals()
        print(self.gui.readDate.toString("dd.mm.yy")) #defining date format
        self.gui.show()
        self.worker.dataChanged.connect(self.onDataChanged) #connects to onDataChanged function when data is changed
        

    ''' functioning of various buttons'''
    def _connectSignals(self):
        self.gui.start.clicked.connect(self.worker.startWork) #Start Button
        self.gui.stop.clicked.connect(self.forceWorkerQuit) #Stop Button
        self.gui.comboBox.activated.connect(self.comboActive) #ComboBox
        
    def comboActive(self):
        self.gui.start.setEnabled(True) #enables start button
        splD = str(self.gui.date.text().split('/')) #spliting date
        self.day = splD[2:4] #day
        self.mnth = splD[8:10] #month
        self.year = splD[16:18] #year
        splT = str (self.gui.timeEd.text().split(':')) #splitting timer
        self.hour = splT[2:4] #hours
        self.minute = splT[8:10] #minutes
        ab = ('sudo date '+ self.mnth + self.day
                                    +str(self.hour) +str(self.minute)
                                    +self.year)         
        os.system(ab) #sets date and time in raspberrypi
        self.TimerT =int(self.gui.comboBox.currentText()) #getting combobox data
        self.worker.setTime(self.TimerT)
        time.sleep(10)
        
    def onDataChanged(self, S0, S1, S2, S3, S4, S5): #data displayed on LCD 
        self.gui.lcd1.display(S0)
        self.gui.lcd2.display(S1)
        self.gui.lcd3.display(S2)
        self.gui.lcd4.display(S3)
        self.gui.lcd5.display(S4)
        self.gui.lcd6.display(S5)
        self.data = []
        datTim = str(datetime.now())[:-10]
        print(datTim)
        self.data.append(datTim)
        self.data.extend([S0, S1, S2, S3, S4, S5])        
        print(self.data)

        #Disabling Date, Timer and Combo Box when data is acquired
        self.gui.comboBox.setEnabled(False)
        self.gui.date.setEnabled(False)
        self.gui.timeEd.setEnabled(False)
        if (self.temp == 0) :
            self.temp = 1
            datim = (str(datetime.now())[:-10]).replace(':','_')
            self.filename = "/media/pi/"+os.listdir("/media/pi/")[0]+"/"+datim #Defining path of csv file
        
            with open(self.filename + str(".csv"),'a', newline='') as csvfile: #writing headers of sensors into csv file
                writer = csv.writer(csvfile)
                writer.writerow(self.header)
                
        with open(self.filename + str(".csv"),'a', newline='') as csvfile: #writing data of sensors into csv file
            writer = csv.writer(csvfile)
            writer.writerow(self.data)
        
        
    def forceWorkerQuit(self): #to close the gui on clicking Stop  button
        
        if self.worker_thread.isRunning():
            self.worker.qt=0
            self.worker_thread.terminate()
        self.gui.close() 




        



            

from events import *
class Window(QWidget):
    
    def __init__(self): 
        super().__init__() #This super method of this class is used as an extender to the base class
        #self.ser = serial.Serial('/dev/ttyUSB0')
        self.initUI() 
        
        
    def initUI(self):

        '''Defining Grid'''
        grid = QGridLayout()
        self.setLayout(grid)
        grid.setSpacing(10)
        self.readDate = QDate()
        self.ret = QMessageBox()

        ''' CSIO Logo '''
        imageCSIO = QtGui.QPixmap('csio_color.png');
        imageCSIO.scaledToHeight(5)
        imgCSIO = QLabel();
        imgCSIO.setPixmap(imageCSIO);

        ''' Deg Bhapka title Label'''
        lab1 = QLabel()
        lab1.setText('<font size="8"><center><b>DEG BHAPKA DATA LOGGER</b></center>')

        ''' Shutdown icon'''
        imageffdc = QtGui.QPixmap('ffcdImg.png');
        imageffdc.scaledToHeight(1)
        imgffdc = QLabel();
        imgffdc.setPixmap(imageffdc);

        '''Defining Labels'''
        labSubTitle = QLabel()
        labSubTitle.setText('<font size="4"><center>Designed & Developed by <br> CSIR-Central Scientific Instruments Organisation</center></font>')
        dateset = QLabel()
        dateset.setText('<font size="4"><center>Date</center></font>')
        timeset = QLabel()
        timeset.setText('<font size="4"><center>Time</center></font>')        
        samplinglabel = QLabel()
        samplinglabel.setText('<font size="4"><center>Sampling Rate (sec)</center></font>')
        self.temp1 = QLabel()
        self.temp1.setText('<font size="4"><center><b>Deg Temperature(°C)</b></center></font>')
        self.temp2 = QLabel()
        self.temp2.setText('<font size="4"><center><b>Bhapka Temperature(°C)</b></center></font>')                   
        
        self.temp3 = QLabel()
        self.temp3.setText('<font size="4"><center><b>Tank Temperature(°C)</b></center></font>')                   
        
        self.temp4 = QLabel()
        self.temp4.setText('<font size="4"><center><b>Ambient Temperature(°C)</b></center></font>')                  
        
        self.press1 = QLabel()
        self.press1.setText('<font size="4"><center><b>Deg Pressure(KPa)</b></center></font>')                  

        self.press2 = QLabel()
        self.press2.setText('<font size="4"><center><b>Bhapka Pressure(KPa)</b></center></font>')


        '''Adding Date and Timer''' 
        self.date = QDateEdit()
        self.date.setCalendarPopup(True) #enable calendar 
        self.date.setMinimumDate(QDate(2018,1,17) ) #Set the date in calendar
        self.timeEd  = QTimeEdit()

        '''Defining Pushbuttons'''
        self.start = QPushButton("Start", self)
        self.stop = QPushButton("Stop", self)
        self.start.setFixedHeight(80)
        self.start.setStyleSheet("QPushButton {background-color:green; font-weight :bold ;font-size :25pt;}"
                                 "QPushButton:pressed {background-color:blue; font-weight :bold ;font-size :25pt;}"); #Styling for Start Button                                    
        self.stop.setFixedHeight(80)
        self.stop.setStyleSheet("QPushButton{background-color:red; font-weight :bold ;font-size :25pt}"); #Styling for Stop Button

        '''Defining Combo Box'''
        self.comboBox = QComboBox()
        self.comboBox.setGeometry(QRect(40, 40, 491, 31))
        self.comboBox.setObjectName(("Sampling Rate(sec)"))
        self.comboBox.addItem("1") #Adding items in Combo Box        
        self.comboBox.addItem("5")
        self.comboBox.addItem("10")
        self.comboBox.addItem("15")

        '''Defining LCD's'''
        self.lcd1 = QLCDNumber(self)
        self.lcd1.setStyleSheet("QLcdNumber{ font-weight :50}");
        self.lcd2 = QLCDNumber(self)
        self.lcd3 = QLCDNumber(self)
        self.lcd4 = QLCDNumber(self)
        self.lcd5 = QLCDNumber(self)
        self.lcd6 = QLCDNumber(self)

        '''Defining Widgets'''
        grid.addWidget(imgCSIO, 0,0,2,1) #CSIO Logo
        grid.addWidget(lab1, 0,1,1,4) #Deg Bhapka tile label
        grid.addWidget(imgffdc, 0,5,2,1) #Shutdown Icon
        grid.addWidget(labSubTitle, 1,1,1,4) #CSIR Label        
        grid.addWidget(self.start, 6,0,2,1) #Start Button
        grid.addWidget(self.stop, 6,1,2,1) #Stop Button       
        grid.addWidget(self.date, 2,1) #Date Picker        
        grid.addWidget(dateset, 2,0) #Date Label
        grid.addWidget(self.timeEd, 4,1) #Timer
        grid.addWidget(timeset, 4,0) #Time Label
        grid.addWidget(samplinglabel, 3,0) #Sampling Label
        grid.addWidget(self.comboBox, 3,1) #Combo Box
        grid.setRowMinimumHeight(2,48) 
        grid.setRowMinimumHeight(3,48)
        grid.setRowMinimumHeight(4,48)
        grid.addWidget(self.lcd1, 2,4,1,2) #LCD1
        grid.addWidget(self.temp1, 2,2,1,2) #Temperature Label1
        grid.addWidget(self.lcd2, 3,4,1,2) #LCD2
        grid.addWidget(self.temp2, 3,2,1,2) #Temperature Label2
        grid.addWidget(self.lcd3, 4,4,1,2) #LCD3
        grid.addWidget(self.temp3, 4,2,1,2) #Temperature Label3
        grid.addWidget(self.lcd4, 5,4,1,2) #LCD4
        grid.addWidget(self.temp4, 5,2,1,2) #Temperature Label4
        grid.addWidget(self.lcd5, 6,4,1,2) #LCD5
        grid.addWidget(self.press1, 6,2,1,2) #Pressure Label1
        grid.addWidget(self.lcd6, 7,4,1,2) #LCD6
        grid.addWidget(self.press2, 7,2,1,2) #Pressure Label2

        self.setWindowTitle('Deg-Bhapka') #Setting the window title
        self.show() #initialising self

        
    

import serial, itertools, time, random
import os
from datetime import datetime
from PyQt5 import QtGui, QtCore 
from threading import Timer

class WorkerObject(QtCore.QObject):
    
    dataChanged = QtCore.pyqtSignal(float, float, float, float, float, float) #Gets 6 values from the sensors
    signalStatus = QtCore.pyqtSignal(str) #Gets string names for the sensors defined
    
    def __init__(self, timer = 5, parent=None):
        super(self.__class__, self).__init__(parent) #This super method of this class is used as an extender to the base class
        
       # self.ser = serial.Serial('/dev/ttyACM0')
        self.header = [] #Stores sensor definition
        self.s0 = [] #Stores sensor values
        self.s1 = []
        self.s2 = []
        self.s3 = []
        self.s4 = []
        self.s5 = []
        self.qt=1
        self.timerT = timer #Stores sampling rate value
        print('init',self.timerT)        
        
    @QtCore.pyqtSlot()
    def setTime (self,timer):
        self.timerT = timer*60 #Converts time into minutes

    ''' Serial reading and writing of data'''
    def startWork(self):

        while self.qt:
            
            if (self.ser.inWaiting()>0):

                try: #reading data serially                   
                    line = self.ser.readline()
                    print(line)
                    line = str(line).split()
                    calibfactor = 1.171875
                   
                    if line[0]=="b'T0":
                        self.s0.append(float(line[1])) #appending sensor values to defined variables
                        self.s1.append(float(line[3]))
                        self.s2.append(float(line[5]))
                        self.s3.append(float(line[7]))
                        temp  = float(line[9][0:5])* calibfactor #converting pressure sensor value to MPa
                        self.s4.append(temp)
                        self.s5.append(temp)
                        self.dataChanged.emit(self.s0[-1],self.s1[-1],self.s2[-1]
                                              ,self.s3[-1],self.s4[-1],
                                              self.s5[-1])
                        time.sleep(self.timerT)
                        print(self.timerT)
                      
                except:

                    print('skipped')
            



